package com.questlife.app;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.os.Build;

public class ReminderReceiver extends BroadcastReceiver {
    private static final String CHANNEL_ID = "quest_life_reminders";
    @Override
    public void onReceive(Context context, Intent intent) {
        NotificationManager manager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (manager == null) return;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, "تذكيرات QUEST LIFE", NotificationManager.IMPORTANCE_DEFAULT);
            channel.setDescription("تذكيرات المهام والعادات داخل اللعبة");
            manager.createNotificationChannel(channel);
        }
        String title = intent.getStringExtra("title");
        String message = intent.getStringExtra("message");
        Notification.Builder builder = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
            ? new Notification.Builder(context, CHANNEL_ID)
            : new Notification.Builder(context);
        builder.setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle(title == null ? "QUEST LIFE" : title)
            .setContentText(message == null ? "حان موعد مهمتك" : message)
            .setAutoCancel(true);
        try { manager.notify((int) (System.currentTimeMillis() & 0x7fffffff), builder.build()); }
        catch (SecurityException ignored) { }
    }
}
